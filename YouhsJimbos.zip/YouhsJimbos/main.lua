--- STEAMODDED HEADER
--- MOD_NAME: Youh's Jimbos
--- MOD_ID: YOUHJIMBOS
--- MOD_AUTHOR: [youhwithanh]
--- MOD_DESCRIPTION: Some new jokers.
--- PREFIX: youh
----------------------------------------------
------------MOD CODE -------------------------

awesome = 0

SMODS.current_mod.optional_features = function()
    return {
        retrigger_joker = true,
    }
end
SMODS.Atlas{
	key = 'Jokers',
	path = 'Jokers.png',
	px = 71,
	py = 95
}
SMODS.Atlas{
	key = 'Decks',
	path = 'Decks.png',
	px = 71,
	py = 95
}
SMODS.Atlas{
	key = 'MonoSleeve',
	path = 'MonoSleeve.png',
	px = 71,
	py = 95
}
SMODS.Atlas{
	key = 'GamblerSleeve',
	path = 'GamblerSleeve.png',
	px = 71,
	py = 95
}
SMODS.Joker{
	key = 'tutor',
	loc_txt = {
		name = 'Tutor Joker',
		text = {
			'{X:mult,C:white}X#1# {} Mult, ',
			'adds {X:mult,C:white}X0.25 {} per beaten Blind'
			},
	},
	atlas = 'Jokers',
	rarity = 3,
	cost = 8,
	blueprint_compat = true,
	perishable_compat = false,
	eternal_compat = false,
	pos = {x = 0, y = 0},
	    in_pool = function(self,wawa,wawa2)
		allow_duplicates = false
        return true
    end,
	config = { 
		extra = {
			Xmult = 2,
			Xmultgain = 0.25}
		},
	loc_vars = function(self,info_queue,center)
		return{vars = {center.ability.extra.Xmult}}
	end,
	calculate = function(self,card,context)
		if context.joker_main then 
		return {
			colour = G.C.MULT,
			Xmult = card.ability.extra.Xmult}
		end
		if context.end_of_round and not context.individual and not context.repetition then
		card.ability.extra.Xmult = card.ability.extra.Xmult + card.ability.extra.Xmultgain
		return {
			end_of_round = true,
			card = card,
			message = 'Lesson taught!'}
		end
	end,
}
SMODS.Joker{
	key = 'absentia',
	loc_txt = {
		name = 'In Absentia Balatro',
		text = {
			'If this is the only joker, ',
			'{C:chips}+1{} Chips and {C:mult}+1{} Mult'
			},
	},
	atlas = 'Jokers',
	rarity = 3,
	cost = 20,
	blueprint_compat = false,
	perishable_compat = false,
	eternal_compat = false,
	pos = {x = 1, y = 0},
	config = { 
		extra = {
			chips = 1000,
			mult = 100}
		},
	loc_vars = function(self,info_queue,center)
		return{vars = {center.ability.extra.chips,center.ability.extra.mult}}
	end,
	calculate = function(self,card,context)
		if context.joker_main and #G.jokers.cards == 1 then 
		return {
			mult = card.ability.extra.mult,
			chips = card.ability.extra.chips}
		end
	end,
}
SMODS.Joker{
	key = 'vessel',
	loc_txt = {
		name = 'Foolish Vessel',
		text = {
			'{C:chips}+#1#{} Chips'
			},
	},
	atlas = 'Jokers',
	rarity = 1,
	cost = 4,
	blueprint_compat = true,
	perishable_compat = false,
	eternal_compat = false,
	pos = {x = 2, y = 0},
	    in_pool = function(self,wawa,wawa2)
		allow_duplicates = false
        return true
    end,
	config = { 
		extra = {
			chips = 75}
		},
	loc_vars = function(self,info_queue,center)
		return{vars = {center.ability.extra.chips}}
	end,
	calculate = function(self,card,context)
		if context.joker_main then 
		return {
			chips = card.ability.extra.chips}
		end
	end,
}
SMODS.Joker{
	key = 'berry',
	loc_txt = {
		name = 'Golden Berry',
		text = {
			'Earn {C:attention}$#1#{} for every',
			'{C:attention}gold card{} in your deck at',
			'the end of round'
			},
	},
	atlas = 'Jokers',
	rarity = 3,
	cost = 10,
	blueprint_compat = false,
	perishable_compat = false,
	eternal_compat = false,
	pos = {x = 3, y = 0},
	    in_pool = function(self,wawa,wawa2)
		allow_duplicates = false
        return true
    end,
	config = { 
		extra = {
			dollars = 3}
		},
    loc_vars = function(self,info_queue,card)
		info_queue[#info_queue+1] = G.P_CENTERS.m_gold
        local gold_tally = 0
        if G.playing_cards then
            for _, playing_card in ipairs(G.playing_cards) do
                if SMODS.has_enhancement(playing_card, "m_gold") then gold_tally = gold_tally + 1 end
            end
        end
        return { vars = { card.ability.extra.dollars, card.ability.extra.dollars * gold_tally } }
    end,
    calc_dollar_bonus = function(self, card)
        local gold_tally = 0
        for _, playing_card in ipairs(G.playing_cards) do
            if SMODS.has_enhancement(playing_card, "m_gold") then gold_tally = gold_tally + 1 end
        end
        return gold_tally > 0 and card.ability.extra.dollars * gold_tally or nil
    end,
}
SMODS.Joker{
	key = 'cybergrind',
	loc_txt = {
		name = 'The Cybergrind',
		text = {
			'{X:mult,C:white}X1 {} Mult',
			'{X:mult,C:white}X#1# {} Mult for each',
			'joker you have'
			},
	},
	atlas = 'Jokers',
	rarity = 2,
	cost = 6,
	blueprint_compat = true,
	perishable_compat = false,
	eternal_compat = false,
	pos = {x = 4, y = 0},
	    in_pool = function(self,wawa,wawa2)
		allow_duplicates = false
        return true
    end,
	config = { 
		extra = {
			Xmultgain = 0.2,
			Xmult = 1}
		},
	loc_vars = function(self,info_queue,center)
	 return { vars = { center.ability.extra.Xmultgain, center.ability.extra.Xmult, center.ability.extra.Xmult * (G.jokers and #G.jokers.cards or 0) }}
	end,
	calculate = function(self,card,context)
		if context.joker_main then 
		return {
			Xmult = card.ability.extra.Xmult + (card.ability.extra.Xmultgain * #G.jokers.cards)}
		end
	end,
}
SMODS.Joker{
	key = 'halloween',
	loc_txt = {
		name = 'Ghoul Joker',
		text = {
			'{C:green}#1#{}/{C:green}#2#{} chance to give',
			'{C:attention}$#5#{} when triggered',
			'{C:green}#1#{}/{C:green}#3#{} chance to give',
			'{C:mult}+#4#{} Mult when triggered'
			},
	},
	atlas = 'Jokers',
	rarity = 1,
	cost = 5,
	blueprint_compat = true,
	perishable_compat = false,
	eternal_compat = false,
	pos = {x = 5, y = 0},
	    in_pool = function(self,wawa,wawa2)
		allow_duplicates = false
        return true
    end,
	config = { 
		extra = {
			odds = 6,
			odds2 = 2,
			mult = 10,
			dollars = 5}
		},
	loc_vars = function(self,info_queue,center)
		return{vars = {G.GAME.probabilities.normal,center.ability.extra.odds,center.ability.extra.odds2,center.ability.extra.mult,center.ability.extra.dollars}}
	end,
	calculate = function(self,card,context)
		if context.joker_main then 
			if pseudorandom('gros_michel') < G.GAME.probabilities.normal / card.ability.extra.odds then
			return {
				dollars = card.ability.extra.dollars}
			end
			if pseudorandom('bloodstone') < G.GAME.probabilities.normal / card.ability.extra.odds2 then
			return {
				mult = card.ability.extra.mult}
			end
		end
	end,
}
SMODS.Joker{
	key = 'roflcopter',
	loc_txt = {
		name = 'ROFLCOPTER!!! LOL',
		text = {
			'Retrigger all modded jokers once'
			},
	},
	atlas = 'Jokers',
	rarity = 3,
	cost = 8,
	blueprint_compat = true,
	perishable_compat = false,
	eternal_compat = false,
	pos = {x = 6, y = 0},
	    in_pool = function(self,wawa,wawa2)
		allow_duplicates = false
        return true
    end,
	config = { 
		extra = {
			chips = 75}
		},
	loc_vars = function(self,info_queue,center)
		return{vars = {center.ability.extra.chips}}
	end,
	calculate = function(self,card,context)
		if context.retrigger_joker_check and not context.retrigger_joker and context.other_card ~= self and context.other_card.config.center.mod then 
		return { repetitions = 1,
		message = 'Again!'}
		end
	end,
}
SMODS.Joker{
	key = 'holypope',
	loc_txt = {
		name = 'Pope Jimbo I',
		text = {
			'Retrigger all scoring',
			'enhanced cards'
			},
	},
	atlas = 'Jokers',
	rarity = 2,
	cost = 6,
	blueprint_compat = true,
	perishable_compat = false,
	eternal_compat = false,
	pos = {x = 7, y = 0},
	    in_pool = function(self,wawa,wawa2)
		allow_duplicates = false
        return true
    end,
	config = { 
		extra = {
			chips = 75}
		},
	loc_vars = function(self,info_queue,center)
		return{vars = {center.ability.extra.chips}}
	end,
	calculate = function(self,card,context)
		if context.cardarea == G.play and context.repetition and next(SMODS.get_enhancements(context.other_card)) then 
		return {
			repetitions = 1,
			}
		end
	end,
}
SMODS.Joker{
	key = 'hrt',
	loc_txt = {
		name = 'HRT',
		text = {
			'Before scoring, turn all',
			'kings into queens and all',
			'queens into kings'
			},
	},
	atlas = 'Jokers',
	rarity = 2,
	cost = 8,
	blueprint_compat = false,
	perishable_compat = false,
	eternal_compat = false,
	pos = {x = 8, y = 0},
	    in_pool = function(self,wawa,wawa2)
		allow_duplicates = false
        return true
    end,
	config = { 
		extra = {
			chips = 75}
		},
	loc_vars = function(self,info_queue,center)
		return{vars = {center.ability.extra.chips}}
	end,
	calculate = function(self,card,context)
		if context.before and context.main_eval then 
			for i,v in ipairs(G.play.cards) do 
				if v:get_id() == 13 then SMODS.change_base(v, nil, 'Queen') end
				if v:get_id() == 12 then SMODS.change_base(v, nil, 'King') end
			end
		end
	end,
}
SMODS.Joker{
	key = 'entrepreneur',
	loc_txt = {
		name = 'Enterpreneur Joker',
		text = {
			'Gain {C:money}$10{} if score',
			'is more than double the',
			'required blind chips'
			},
	},
	atlas = 'Jokers',
	rarity = 1,
	cost = 5,
	blueprint_compat = false,
	perishable_compat = false,
	eternal_compat = false,
	pos = {x = 9, y = 0},
	    in_pool = function(self,wawa,wawa2)
		allow_duplicates = false
        return true
    end,
	config = { 
		extra = {
			dollars = 10}
		},
	loc_vars = function(self,info_queue,center)
		return{vars = {center.ability.extra.dollars}}
	end,
	calculate = function(self,card,context)
		if context.end_of_round and G.GAME.chips > 2 * G.GAME.blind.chips and context.main_eval then
		return {
		dollars = card.ability.extra.dollars
		}
		end
	end,
}
SMODS.Joker{
	key = 'invincible',
	loc_txt = {
		name = 'Joker Invincible',
		text = {
			'This is my invincible war',
			'OC his name is {C:dark_edition}Joker Invincible{}',
			'and he gives {X:mult,C:white}X2{} Mult'
			},
	},
	atlas = 'Jokers',
	rarity = 1,
	cost = 6,
	blueprint_compat = true,
	perishable_compat = false,
	eternal_compat = false,
	pos = {x = 10, y = 0},
	    in_pool = function(self,wawa,wawa2)
		allow_duplicates = false
        return true
    end,
	config = { 
		extra = {
			Xmult = 2}
		},
	loc_vars = function(self,info_queue,center)
		return{vars = {center.ability.extra.Xmult}}
	end,
	calculate = function(self,card,context)
		if context.joker_main then 
		return {
			Xmult = card.ability.extra.Xmult}
		end
	end,
}
SMODS.Joker{
	key = 'egg',
	loc_txt = {
		name = 'Strange Egg',
		text = {
			'Not too important, not too unimportant.',
			'{X:mult,C:white}X#1#{} Mult'
			},
	},
	atlas = 'Jokers',
	rarity = 4,
	cost = 40,
	blueprint_compat = true,
	perishable_compat = false,
	eternal_compat = false,
	pos = {x = 11, y = 0},
	config = { 
		extra = {
			Xmult = 6.6}
		},
	loc_vars = function(self,info_queue,center)
		return{vars = {center.ability.extra.Xmult}}
	end,
	calculate = function(self,card,context)
		if context.joker_main then 
		return {
			Xmult = card.ability.extra.Xmult}
		end
	end,
}
SMODS.Joker{
	key = 'tree',
	loc_txt = {
		name = 'Tree',
		text = {
			'Well, there is a man here.',
			'He told you to wait 6 rounds.',
			'{C:inactive}(Currently {C:attention}#1#{C:inactive}/#2#)'
			},
	},
	atlas = 'Jokers',
	rarity = 1,
	cost = 1,
	blueprint_compat = false,
	perishable_compat = false,
	eternal_compat = false,
	pos = {x = 12, y = 0},
	config = { 
		extra = {
			current = 0,
			wait = 6}
		},
	loc_vars = function(self,info_queue,center)
		return{vars = {center.ability.extra.current,center.ability.extra.wait}}
	end,
	calculate = function(self,card,context)
		if context.selling_card and card.ability.extra.current >= card.ability.extra.wait then
		local card = create_card('Joker', G.jokers, nil, nil, nil, nil, 'j_youh_egg')
		card:add_to_deck()
		G.jokers:emplace(card)
		end
        if context.end_of_round and context.game_over == false and context.main_eval and not context.blueprint then
            card.ability.extra.current = card.ability.extra.current + 1
            if card.ability.extra.current == card.ability.extra.total_rounds then
                local eval = function(card) return not card.REMOVED end
                juice_card_until(card, eval, true)
            end
            return {
                message = (card.ability.extra.current < card.ability.extra.wait) and
                    (card.ability.extra.current .. '/' .. card.ability.extra.wait) or
                    'He offered you something.',
                colour = G.C.FILTER
            }
        end
	end,
}




-- i need to like put this in a different category i guess
SMODS.Back{
	key = 'mono',
	loc_txt = {
		name = "MonoDeck",
		text = {
		'Start with {C:attention}In Absentia Balatro{}',
		'and 1 joker slot'
		}
	},
	atlas = 'Decks',
	unlock = true,
	pos = {x = 0, y = 0},
	config = {
		extra = {
			joker_slot = -4}
	},
    loc_vars = function(self, info_queue, back)
        return { vars = { self.config.extra.joker_slot} }
    end,
	apply = function(self,back)
		G.GAME.starting_params.joker_slots = 1
			G.E_MANAGER:add_event(Event{
			func = function()
				local card = create_card('Joker', G.jokers, nil, nil, nil, nil, 'j_youh_absentia')
				card:add_to_deck()
				G.jokers:emplace(card)
			return true
			end
		})
	end,
}
SMODS.Back{
	key = 'gambling',
	loc_txt = {
		name = "Gambler's Deck",
		text = {
		'{X:mult,C:white}X#1#{} Mult, {C:green}1 in 4{} chance for',
		'hand to not score'
		}
	},
	atlas = 'Decks',
	unlock = true,
	pos = {x = 1, y = 0},
	config = {
		extra = {
			Xmult = 3,
			odds = 4}
	},
    loc_vars = function(self, info_queue, back)
        return { vars = { self.config.extra.Xmult, self.config.extra.odds} }
    end,
	calculate = function(self,card,context)
		if context.final_scoring_step then
			if pseudorandom('blahblahblah') >= G.GAME.probabilities.normal / self.config.extra.odds then
			return { Xmult = self.config.extra.Xmult}
			end
			if pseudorandom('blahblahblah') < G.GAME.probabilities.normal / self.config.extra.odds then
			hand_chips = 0
			mult = 0
			end
		end
	end,
}
CardSleeves.Sleeve{
	key = 'mono',
	loc_txt = {
		name = "MonoSleeve",
		text = {
		'Start with {C:attention}In Absentia Balatro{}',
		'and 1 joker slot'
		}
	},
	atlas = 'MonoSleeve',
	unlocked = true,
	unlock_condition = { deck = "MonoDeck", stake = 1 },
	pos = {x = 0, y = 0},
	config = {
		extra = {
			joker_slot = -4}
	},
    loc_vars = function(self, info_queue, back)
        return { vars = { self.config.extra.joker_slot} }
    end,
	apply = function(self,back)
		G.GAME.starting_params.joker_slots = 1
			G.E_MANAGER:add_event(Event{
			func = function()
				local card = create_card('Joker', G.jokers, nil, nil, nil, nil, 'j_youh_absentia')
				card:add_to_deck()
				G.jokers:emplace(card)
			return true
			end
		})
	end,
}
CardSleeves.Sleeve{
	key = 'gambling',
	loc_txt = {
		name = "Gambler's Sleeve",
		text = {
		'{X:mult,C:white}X#1#{} Mult, {C:green}1 in 4{} chance for',
		'hand to not score'
		}
	},
	atlas = 'GamblerSleeve',
	unlocked = true,
	pos = {x = 0, y = 0},
	config = {
		extra = {
			Xmult = 3,
			odds = 4}
	},
    loc_vars = function(self, info_queue, back)
        return { vars = { self.config.extra.Xmult, self.config.extra.odds} }
    end,
	calculate = function(self,card,context)
		if context.final_scoring_step then
			if pseudorandom('blahblahblah') >= G.GAME.probabilities.normal / self.config.extra.odds then
			return { Xmult = self.config.extra.Xmult}
			end
			if pseudorandom('blahblahblah') < G.GAME.probabilities.normal / self.config.extra.odds then
			hand_chips = 0
			mult = 0
			end
		end
	end,
}

  
----------------------------------------------
------------MOD CODE END----------------------
    